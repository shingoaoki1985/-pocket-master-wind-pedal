# Pocket Master Pedal V5 差分パッチ

対象は SONICAKE Pocket Master（QME-10）の純正ファームウェア **V1.3.3** です。この非公式パッチを適用すると、譜めくり用の PEDAL とウィンドシンセ機能を含む V5 の書き込み用ファイルを生成できます。

## 適用手順

1. [SONICAKE 公式ダウンロードページ](https://www.sonicake.com/pages/pocket-master-software-firmware-download-qme-10)から **Pocket Master Firmware V1.3.3** を入手し、純正の `.bin` を展開します。
2. このパッチの ZIP を展開し、`apply_patch.py` のあるフォルダで PowerShell を開きます。以下の純正ファイルのパスは、実際の保存先に置き換えてください。Python 3 が必要です。

   ```powershell
   py -3 .\apply_patch.py 'C:\path\to\official-v1.3.3.bin' .\Pocket_Master_Pedal_V5.bin
   ```

3. `Created:` と SHA-256 が表示されたら、生成した `Pocket_Master_Pedal_V5.bin` を Sonicake Manager のファームウェア更新で選択します。

適用スクリプトは、生成前に純正ファームの SHA-256 を、生成後に書き込み用ファイルの SHA-256 を確認します。既存ファイルがある場合は、別の出力名を指定してください。

## PEDAL の使い方

ホーム画面で VALUE/VOL を長押ししてメニューを開き、PEDAL を選びます。iPad の「設定 → Bluetooth」で Pocket Pedal または Pocket Master BLE を選び、画面が `BLUETOOTH CONNECTED` になったら L で ←、R で → を送れます。譜面アプリでの動作は、そのアプリのキーボード割り当てに従います。VALUE/VOL を短く押すとメニューに戻ります。

## 同梱ファイル

- `Pocket_Master_Pedal_V5.patch.json` は追加・変更データと、手元の純正ファームからコピーする範囲を記録した差分です。
- `apply_patch.py` は差分の適用スクリプトです。
- `source/` は V5 のビルド用ソースとライセンスです。パッチ適用には Andes のコンパイラは不要です。
