#!/usr/bin/env python3
"""Build the Pocket Master Pedal V5 image from an exact stock firmware file."""

import argparse
import hashlib
import json
from pathlib import Path


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def apply(stock, patch):
    if patch["format"] != "pocket-master-firmware-delta-1":
        raise ValueError("Unsupported patch format.")
    if sha256(stock) != patch["stock_sha256"]:
        raise ValueError("Input must be the supported, unmodified Sonicake Pocket Master V1.3.3 image.")

    result = bytearray()
    for operation in patch["operations"]:
        if isinstance(operation, str):
            result.extend(bytes.fromhex(operation))
            continue
        offset, length = operation
        if offset < 0 or length <= 0 or offset + length > len(stock):
            raise ValueError("Patch refers to bytes outside the stock image.")
        result.extend(stock[offset:offset + length])

    if len(result) != patch["output_size"] or sha256(result) != patch["output_sha256"]:
        raise ValueError("Output checksum mismatch. No firmware was written.")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stock", type=Path, help="unmodified Sonicake Pocket Master V1.3.3 .bin")
    parser.add_argument("output", type=Path, help="new output .bin path")
    args = parser.parse_args()
    patch_file = Path(__file__).with_name("Pocket_Master_Pedal_V5.patch.json")
    try:
        patch = json.loads(patch_file.read_text(encoding="utf-8"))
        result = apply(args.stock.read_bytes(), patch)
        with args.output.open("xb") as output:
            output.write(result)
    except FileExistsError:
        parser.exit(1, "Error: Output already exists. Use a different output path.\n")
    except (OSError, ValueError, TypeError, KeyError) as error:
        parser.exit(1, f"Error: {error}\n")
    print(f"Created: {args.output.resolve()}")
    print(f"SHA-256: {patch['output_sha256']}")


if __name__ == "__main__":
    main()
