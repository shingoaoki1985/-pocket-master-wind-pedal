@echo off
setlocal
cd /d "%~dp0.."
if not defined QME10_ANDES_BIN set "QME10_ANDES_BIN=%CD%\work\andes-win\nds32le-elf-mculib-v3f\bin"
if not defined QME10_CYGWIN_BIN set "QME10_CYGWIN_BIN=%CD%\work\andes-cygwin\bin"
if not defined QME10_PYTHON set "QME10_PYTHON=%LOCALAPPDATA%\Python\pythoncore-3.14-64\python.exe"
set "PATH=%QME10_CYGWIN_BIN%;%QME10_ANDES_BIN%;%PATH%"
"%QME10_PYTHON%" molecular\device\stock_wind\build.py work\stock_v1.3.3.bin outputs\Pocket_Master_Pedal_V5_candidate.bin --pedal
exit /b %ERRORLEVEL%
