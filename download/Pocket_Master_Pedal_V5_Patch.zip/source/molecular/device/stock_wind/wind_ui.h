/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef STOCK_WIND_UI_H
#define STOCK_WIND_UI_H

#include <stdint.h>

enum {
    WIND_NOTE_SEEN = 1u,
    WIND_CC2_SEEN = 2u,
    WIND_CC74_SEEN = 4u,
    WIND_GATE = 8u
};

typedef struct {
    uint32_t notifications;
    uint8_t messages;
    uint8_t link, link_tracked;
    uint8_t note, channel, cc2, cc74, flags;
    uint8_t audio_seen, pcm_active, fx_ack;
} wind_status_t;

wind_status_t wind_get_status(void);

enum {
    WIND_WAVE_COUNT = 3,
    WIND_CUTOFF_MAX = 127,
    WIND_BEND_RANGES = 3
};

extern const uint8_t wind_bend_ranges[WIND_BEND_RANGES];
extern const uint16_t wind_cutoff_hz[WIND_CUTOFF_MAX + 1];
void wind_set_controls(unsigned wave, unsigned cutoff, unsigned bend_range);
unsigned wind_get_breath_cc(unsigned secondary);
void wind_set_breath_cc(unsigned secondary, unsigned cc);
unsigned wind_get_fx_route(void);
void wind_set_fx_route(unsigned enabled);
unsigned wind_get_env(unsigned part);
void wind_set_env(unsigned part, unsigned value);

enum { WIND_ATTACK, WIND_DECAY, WIND_SUSTAIN, WIND_RELEASE, WIND_ENV_PARTS };

#endif
