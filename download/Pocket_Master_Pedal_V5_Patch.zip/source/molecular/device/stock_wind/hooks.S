/* SPDX-License-Identifier: GPL-3.0-only */
    .section .text.hooks, "ax"
    .align 2
    .global wind_att_hook
wind_att_hook:
    addi $sp, $sp, -24
    swi $lp, [$sp + 20]
    swi $r0, [$sp]
    swi $r1, [$sp + 4]
    swi $r2, [$sp + 8]
    swi $r3, [$sp + 12]
    swi $r4, [$sp + 16]
    addi $r0, $r2, 0
    addi $r1, $r3, 0
    jal wind_stock_receive
    lwi $r0, [$sp]
    lwi $r1, [$sp + 4]
    lwi $r2, [$sp + 8]
    lwi $r3, [$sp + 12]
    lwi $r4, [$sp + 16]
    lwi $lp, [$sp + 20]
    addi $sp, $sp, 24
    j stock_att_dispatch

    .align 2
    .global wind_audio_hook
wind_audio_hook:
    addi $sp, $sp, -16
    swi $r0, [$sp]
    swi $r1, [$sp + 4]
    swi $r2, [$sp + 8]
    swi $lp, [$sp + 12]
    jal wind_stock_audio_transfer
    lwi $r0, [$sp]
    lwi $r1, [$sp + 4]
    lwi $r2, [$sp + 8]
    lwi $lp, [$sp + 12]
    addi $sp, $sp, 16
    j stock_spis_submit

    .align 2
    .global wind_link_hook
wind_link_hook:
    addi $sp, $sp, -16
    swi $r0, [$sp]
    swi $r1, [$sp + 4]
    swi $r2, [$sp + 8]
    swi $lp, [$sp + 12]
    jal wind_stock_link
    lwi $r0, [$sp]
    lwi $r1, [$sp + 4]
    lwi $r2, [$sp + 8]
    lwi $lp, [$sp + 12]
    addi $sp, $sp, 16
    addi.gp $r2, -0x7590
    j stock_link_continue

    .align 2
    .global wind_disconnect_hook
wind_disconnect_hook:
    addi $sp, $sp, -8
    swi $lp, [$sp + 4]
    addi $r0, $r7, 0
    jal wind_stock_disconnect
    lwi $lp, [$sp + 4]
    addi $sp, $sp, 8
    j stock_link_value

    .align 2
    .global wind_menu_enter_hook
wind_menu_enter_hook:
    addi $sp, $sp, -8
    swi $lp, [$sp + 4]
    swi $r0, [$sp]
    addi $r0, $r6, 0
    jal wind_stock_menu_enter
    lwi $r0, [$sp]
    lwi $lp, [$sp + 4]
    addi $sp, $sp, 8
    j stock_menu_marker

    .align 2
    .global wind_menu_destroy_hook
wind_menu_destroy_hook:
    addi $sp, $sp, -8
    swi $lp, [$sp + 4]
    swi $r0, [$sp]
    jal wind_stock_menu_destroy
    lwi $r0, [$sp]
    lwi $lp, [$sp + 4]
    addi $sp, $sp, 8
    j stock_menu_delete

#ifdef WIND_PEDAL_ENABLED
    .align 2
    .global pedal_stock_poll_hook
pedal_stock_poll_hook:
    addi $sp, $sp, -32
    swi $lp, [$sp + 24]
    swi $r0, [$sp]
    swi $r1, [$sp + 4]
    swi $r2, [$sp + 8]
    swi $r3, [$sp + 12]
    swi $r4, [$sp + 16]
    swi $r5, [$sp + 20]
    jal pedal_stock_poll
    lwi $r0, [$sp]
    lwi $r1, [$sp + 4]
    lwi $r2, [$sp + 8]
    lwi $r3, [$sp + 12]
    lwi $r4, [$sp + 16]
    lwi $r5, [$sp + 20]
    lwi $lp, [$sp + 24]
    addi $sp, $sp, 32
    j stock_task_service
#endif
