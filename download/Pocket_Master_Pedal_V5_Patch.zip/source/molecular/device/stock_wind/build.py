#!/usr/bin/env python3
# SPDX-License-Identifier: GPL-3.0-only
"""Build the BLE wind voice against the supported stock QME-10 v1.3.3 image."""
import argparse
import hashlib
import math
import os
from pathlib import Path
import struct
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parents[1] / "tools"))
from htfw import Image, Section, rebuild

STOCK_HASH = "d9112f12a37e3731e540b325d2b9788f005de7f640c129ac30465ea1dc57e7a3"
BASE = 0x10000
PAYLOAD = 0x16BB60
LIMIT = 0x170000
BRANCHES = (
    (0x94BA8, "49fdf944", "wind_att_hook", 0x49),
    (0x2418, "4802ebdc", "wind_audio_hook", 0x48),
    (0x5068, "3e2f8a70", "wind_link_hook", 0x48),
    (0x53FDC, "49fd883c", "wind_disconnect_hook", 0x49),
    (0x1C44C, "4900d076", "wind_ui_tick", 0x49),
    (0x3A9CC, "4900310e", "wind_ui_blit", 0x49),
    (0x5D80, "49000340", "wind_stock_front_input", 0x49),
    (0x1C27C, "48ff50c2", "wind_stock_key_input", 0x48),
    (0x16302, "49ff7fbf", "wind_menu_enter_hook", 0x49),
    (0x1671A, "49006933", "wind_menu_destroy_hook", 0x49),
)
RAM_CHANGES = (
    # Extend startup zeroing and start the heap after the 160-byte wind state.
    (0x526CC, "3e28c148", "3e28c1e8"),
    (0x58C62, "3e38c148", "3e38c1e8"),
)
PEDAL_BRANCHES = (
    (0x4F00C, "4902051d", "pedal_stock_init", 0x49),
    # Poll before the stock task can skip its Bluetooth housekeeping branch.
    (0x50D00, "49ff5fc2", "pedal_stock_poll_hook", 0x49),
)
PEDAL_RAM_CHANGES = (
    (0x526CC, "3e28c148", "3e28c208"),
    (0x58C62, "3e38c148", "3e38c208"),
)
ARM_IMAGE_BASE = 0x4000
ARM_INPUT_STORE = 0x5A78
ARM_INPUT_STORE_BYTES = bytes.fromhex("40f8046b")


def write_tables(build):
    sine = [round(32767 * math.sin(math.tau * i / 256)) for i in range(256)]
    step = [round((440 * 2 ** ((i - 69) / 12)) * 2**32 / 44100) for i in range(128)]
    cutoff = [round(80 * 100 ** (i / 126)) for i in range(127)] + [0]
    coefficients = [round(32768 * (1 - math.exp(-math.tau * hz / 44100))) for hz in cutoff]
    with (build / "wind_tables.h").open("w", encoding="ascii") as out:
        for scope, ctype, name, values in (
            ("static ", "int16_t", "wind_sine", sine),
            ("static ", "uint32_t", "wind_step", step),
            ("", "uint16_t", "wind_cutoff_hz", cutoff),
            ("static ", "uint16_t", "wind_filter", coefficients),
        ):
            print(f"{scope}const {ctype} {name}[] = {{", file=out)
            for i in range(0, len(values), 8):
                print("    " + ", ".join(map(str, values[i:i + 8])) + ",", file=out)
            print("};", file=out)


def branch(opcode, origin, target):
    delta = target - origin
    if delta % 2 or not -0x1000000 <= delta < 0x1000000:
        raise ValueError("hook branch is outside the instruction range")
    return bytes((opcode,)) + (delta // 2 & 0xffffff).to_bytes(3, "big")


def thumb_bl(origin, target):
    delta = target - origin - 4
    if delta & 1 or not -(1 << 24) <= delta < (1 << 24):
        raise ValueError("ARM hook branch is outside the instruction range")
    s = (delta >> 24) & 1
    j1 = 1 ^ (delta >> 23 & 1) ^ s
    j2 = 1 ^ (delta >> 22 & 1) ^ s
    return struct.pack("<HH", 0xf000 | s << 10 | (delta >> 12 & 1023),
                       0xd000 | j1 << 13 | j2 << 11 | (delta >> 1 & 2047))


def arm_pre_fx(data):
    """Add the marked SPI synth stream at the ARM's physical input boundary.

    At 0x5A78 r6 holds the stock mono input sample, r0 its destination,
    and r1 the sample count (64 down to 1). r7 and r8 are saved by the
    stock prologue and available here. r5 and r4 have advanced one word
    past the two ADC samples. Mirror the stock (left - right) / 2
    polarity, and update both the raw input and the derived mono sample.
    """
    patch_at = ARM_INPUT_STORE - ARM_IMAGE_BASE
    expected_input = bytes.fromhex("55f8046b54f8047bf61b7610") + ARM_INPUT_STORE_BYTES
    if len(data) != 0xc63c or data[patch_at - 12:patch_at + 4] != expected_input:
        raise ValueError("unexpected stock ARM audio routine")
    hook_at = ARM_IMAGE_BASE + len(data)
    hook = struct.pack(
        "<40H",
        0x4f13,            # ldr r7, marker address
        0x683f,            # ldr r7, [r7]
        0xf8df, 0x804c,     # ldr.w r8, marker value
        0x4547,            # cmp r7, r8
        0x4f13,            # ldr r7, response address (preserves flags)
        0xd119,            # bne clear
        0xf8c7, 0x8000,     # str.w r8, [r7] (echo marker)
        0x4f12,            # ldr r7, mono buffer end
        0xeba7, 0x0741,     # sub.w r7, r7, r1, lsl #1
        0xf897, 0x8001,     # ldrb.w r8, [r7, #1]
        0x783f,            # ldrb r7, [r7]
        0xea47, 0x2708,     # orr.w r7, r7, r8, lsl #8
        0x043f,            # lsls r7, r7, #16
        0xfa86, 0xf687,     # qadd r6, r6, r7
        0xf855, 0x8c04,     # ldr.w r8, [r5, #-4]
        0xfa88, 0xf887,     # qadd r8, r8, r7
        0xf845, 0x8c04,     # str.w r8, [r5, #-4]
        0xf854, 0x8c04,     # ldr.w r8, [r4, #-4]
        0xfa87, 0xf8a8,     # qsub r8, r8, r7
        0xf844, 0x8c04,     # str.w r8, [r4, #-4]
        0xe003,            # b store
        0xf04f, 0x0800,     # clear: mov.w r8, #0
        0xf8c7, 0x8000,     # str.w r8, [r7]
        0xf840, 0x6b04,     # store: str.w r6, [r0], #4
        0x4770,            # bx lr
    )
    # SPI RX begins at 0x200023bc and arrives one byte late. Write the response
    # into the stock TX buffer's unused tail before its next 512-byte transfer.
    hook += struct.pack("<I4sII", 0x200024c0, b"SYN9", 0x200029b4, 0x20002545)
    if len(data) + len(hook) > 0xd000:
        raise ValueError("ARM audio hook exceeds the last occupied flash page")
    return data[:patch_at] + thumb_bl(ARM_INPUT_STORE, hook_at) + data[patch_at + 4:] + hook


def read_stock(path):
    raw = path.read_bytes()
    if hashlib.sha256(raw).hexdigest() != STOCK_HASH:
        raise ValueError("stock image does not match the supported v1.3.3 build")
    image = Image(raw)
    if image.check() or any(sum(s.tag == tag for s in image.sections) != 1 for tag in ("b", "c")):
        raise ValueError("stock image container is invalid")
    return image


def app_bytes(image, payload, symbols, pedal=False):
    app = bytearray(next(s.data for s in image.sections if s.tag == "b"))
    if BASE + len(app) != PAYLOAD or not payload or PAYLOAD + len(payload) > LIMIT:
        raise ValueError("invalid stock payload address or size")
    ram_changes = PEDAL_RAM_CHANGES if pedal else RAM_CHANGES
    replacements = [(off, old, bytes.fromhex(new)) for off, old, new in ram_changes]
    for off, old, name, opcode in BRANCHES + (PEDAL_BRANCHES if pedal else ()):
        target = symbols[name]
        if not PAYLOAD <= target < PAYLOAD + len(payload):
            raise ValueError(f"{name} is outside the new code")
        replacements.append((off, old, branch(opcode, BASE + off, target)))
    for off, expected, new in replacements:
        if app[off:off + 4] != bytes.fromhex(expected):
            raise ValueError(f"unexpected original instruction at {off:#x}")
        app[off:off + 4] = new
    app.extend(payload)
    return bytes(app)


def write_pedal_profile(image, path):
    app = next(s.data for s in image.sections if s.tag == "b")
    start = 0x142810 - BASE
    table = bytearray(app[start:start + 0x7b])
    if table[:1] != b"\x01" or app[start + len(table):start + len(table) + 2] != b"\0\0":
        raise ValueError("unexpected stock GATT database")
    handle = 7
    definitions = {}

    def record(uuid, flags, value):
        nonlocal handle
        handle += 1
        table.extend(struct.pack("<4H", 8 + len(value), flags, handle, uuid))
        table.extend(value)

    def characteristic(uuid, properties, flags, value=b"", name=None):
        record(0x2803, 0xf002, struct.pack("<BHH", properties, handle + 2, uuid))
        record(uuid, flags, value)
        if name:
            definitions[name] = handle

    record(0x2800, 0xf002, struct.pack("<H", 0x1812))
    characteristic(0x2a4a, 0x02, 0xf402, bytes((0x11, 0x01, 0, 0x02)))
    characteristic(0x2a4b, 0x02, 0xf502, name="MAP")
    characteristic(0x2a4c, 0x04, 0xf105, name="CONTROL")
    characteristic(0x2a4d, 0x12, 0xf502, name="INPUT")
    record(0x2902, 0xf50b, b"\0\0")
    definitions["CCC"] = handle
    record(0x2908, 0xf402, b"\x01\x01")
    # PnP ID uses the existing Pocket Master USB hardware identity.
    record(0x2800, 0xf002, struct.pack("<H", 0x180a))
    characteristic(0x2a50, 0x02, 0xf002, struct.pack("<B3H", 2, 0x84ef, 0x0284, 0x0101))
    table.extend(b"\0\0")

    with path.open("w", encoding="ascii") as out:
        for name, value in definitions.items():
            print(f"#define PEDAL_{name} {value}u", file=out)
        print("static const uint8_t pedal_profile_data[] = {", file=out)
        for offset in range(0, len(table), 16):
            print("    " + ", ".join(f"0x{n:02x}" for n in table[offset:offset + 16]) + ",", file=out)
        print("};", file=out)


def compile_wind(build, image, pedal=False):
    write_tables(build)
    prefix = os.environ.get("NDS_TOOL_PREFIX", "nds32le-elf-")
    arch = ["-mcmodel=medium", "-mcpu=d1088-spu", "-mext-dsp", "-mext-zol"]

    def run(tool, *args, capture=False):
        return subprocess.run([prefix + tool, *map(str, args)], cwd=build, check=True,
                              capture_output=capture, text=capture).stdout

    c_flags = ["-Os", "-std=c99", "-ffreestanding", "-fno-builtin", "-ffunction-sections"]
    pedal_flags = ["-DWIND_PEDAL_ENABLED"] if pedal else []
    run("gcc", *arch, *c_flags, *pedal_flags, "-I", build, "-c", HERE / "wind.c", "-o", "wind.o")
    run("gcc", *arch, *c_flags, *pedal_flags, "-c", HERE / "wind_ui.c", "-o", "wind_ui.o")
    pedal_objects = []
    if pedal:
        write_pedal_profile(image, build / "pedal_profile.h")
        run("gcc", *arch, *c_flags, "-c", HERE / "pedal.c", "-o", "pedal.o")
        run("gcc", *arch, *c_flags, "-I", build, "-c", HERE / "pedal_stock.c", "-o", "pedal_stock.o")
        pedal_objects = ["pedal.o", "pedal_stock.o", "-Wl,-u,pedal_stock_init"]
    run("gcc", *arch, *pedal_flags, "-c", HERE / "hooks.S", "-o", "hooks.o")
    run("gcc", *arch, "-nostdlib", "-static", "-Wl,--gc-sections", "-T", HERE / "wind.ld",
        "-Wl,-u,wind_ui_tick,-u,wind_ui_blit,-u,wind_stock_front_input,-u,wind_stock_key_input",
        "-o", "wind.elf", "hooks.o", "wind.o", "wind_ui.o", *pedal_objects, "-lgcc")
    symbols = {}
    for line in run("nm", "-n", "wind.elf", capture=True).splitlines():
        fields = line.split()
        if len(fields) == 3:
            symbols[fields[2]] = int(fields[0], 16)
    run("objcopy", "-O", "binary", "-j", ".text", "wind.elf", "wind.bin")
    return (build / "wind.bin").read_bytes(), symbols


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("stock", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--pedal", action="store_true", help="include the experimental BLE HID mode")
    args = parser.parse_args()
    if args.stock.resolve() == args.output.resolve():
        parser.error("the stock input and candidate output must be different files")
    image = read_stock(args.stock)
    with tempfile.TemporaryDirectory(prefix="pocket-master-stock-wind-") as tmp:
        payload, symbols = compile_wind(Path(tmp), image, args.pedal)
    app = app_bytes(image, payload, symbols, args.pedal)
    sections = [
        Section(s.tag, s.addr, app if s.tag == "b" else arm_pre_fx(s.data))
        if s.tag in ("b", "c") else s
        for s in image.sections
    ]
    packed = rebuild(image, sections)
    final = Image(packed)
    if final.check() or [s.tag for s, original in zip(final.sections, image.sections) if s.data != original.data] != ["c", "b"]:
        raise ValueError("candidate container verification failed")
    with args.output.open("xb") as out:
        out.write(packed)
    print(f"Candidate: {args.output}")


if __name__ == "__main__":
    main()
