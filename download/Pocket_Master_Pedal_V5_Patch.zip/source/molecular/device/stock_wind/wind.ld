/* SPDX-License-Identifier: GPL-3.0-only */
ENTRY(wind_att_hook)
stock_att_dispatch = 0x63e30;
stock_spis_submit = 0x6fbd0;
stock_link_continue = 0x1506c;
stock_link_value = 0x15054;
stock_gui_timer = 0x46538;
stock_tick = 0x68d60;
stock_lcd_blit = 0x50be8;
stock_invalidate = 0x2f88c;
stock_gpio_get = 0x6bc3c;
stock_post_input = 0x16400;
stock_menu_marker = 0x16280;
stock_menu_delete = 0x33980;
stock_open_page = 0x16288;
stock_ble_init = 0x9fa46;
stock_ble_read = 0x5eea8;
stock_ble_write = 0x5f10c;
stock_ble_notify = 0x9f124;
stock_ble_advertise = 0x9f116;
stock_task_service = 0x4cc84;
SECTIONS
{
    . = 0x16bb60;
    .text : { KEEP(*(.text.hooks)) *(.text .text.*) *(.rodata .rodata.*) }
    . = 0x2001bb88;
    .wind_ram (NOLOAD) : { *(.bss .bss.*) *(COMMON) }
    ASSERT(SIZEOF(.wind_ram) <= 192, "stock wind state exceeds its reserved RAM")
    .unexpected_data : { *(.data .data.* .sdata .sdata.* .sbss .sbss.*) }
    ASSERT(SIZEOF(.unexpected_data) == 0, "unexpected initialized or GP-relative wind data")
    /DISCARD/ : { *(.comment .note.* .eh_frame* .debug* .nds32.attributes) }
}
