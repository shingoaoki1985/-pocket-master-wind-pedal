/* SPDX-License-Identifier: GPL-3.0-only */
#include "wind_ui.h"
#include "wind_font.h"
#ifdef WIND_PEDAL_ENABLED
#include "pedal.h"
#endif

#define SCREEN_W 160u
#define SCREEN_H 128u
#define ROW_H 16u
#if defined(__GNUC__)
#define WIND_NOINLINE __attribute__((noinline))
#else
#define WIND_NOINLINE
#endif
enum {
    WIND_MONITOR, WIND_WAVE, WIND_CUTOFF, WIND_BEND, WIND_CC_MAIN, WIND_CC_ALT,
    WIND_ROUTE, WIND_ENV, WIND_BACK, WIND_ENV_EDIT
};
#ifndef STOCK_DISPLAY_PTR
#define STOCK_DISPLAY_PTR ((void *volatile const *)0x20004a8cu)
#endif

/* Entries from the supported stock v1.3.3 application. */
extern uint32_t stock_gui_timer(void);
extern uint32_t stock_tick(void);
extern void stock_lcd_blit(unsigned x1, unsigned x2, unsigned y1, unsigned y2, const uint16_t *pixels);
extern void stock_invalidate(void *obj);
extern int stock_gpio_get(unsigned reg, uint32_t mask);
extern void stock_post_input(unsigned type, unsigned code, unsigned value, unsigned extra);
extern void stock_open_page(unsigned page, void *argument);

enum {
    STOCK_HOME = 2, STOCK_SETTINGS = 4, STOCK_DRUM = 6,
    STOCK_EFFECTS = 10, STOCK_SHUTDOWN = 14
};

static uint8_t *menu_context;
static uint8_t menu_item, menu_synth;
#ifdef WIND_PEDAL_ENABLED
static uint8_t menu_pedal;
static uint8_t drawn_pedal_ready;
#endif
static uint32_t chord_since, last_draw;
static uint32_t release_since;
static uint8_t chord, latched, panel_open;
static volatile uint8_t input_captured;
static volatile uint8_t knob_action;
static uint8_t release_pending;
static uint8_t redraw, refresh_polls;
static uint8_t selected, wave, cutoff_down, bend_range;
static uint8_t previous_button, previous_encoder;
static wind_status_t drawn;

enum { KNOB_NONE, KNOB_CONFIRM, KNOB_CLOSE };

static uint16_t lcd_color(uint16_t rgb565)
{
    return (uint16_t)((rgb565 << 8) | (rgb565 >> 8));
}

static WIND_NOINLINE void draw_menu(void)
{
    static const char *const names[] = {
        "EFFECTS", "SETTINGS", "DRUM", "SHUTDOWN", "SYNTH",
#ifdef WIND_PEDAL_ENABLED
        "PEDAL",
#endif
    };
    const unsigned count = sizeof names / sizeof names[0];
    enum { CELL_W = 52, CELL_H = 36, MENU_TOP = 17 };
    const uint16_t bg = lcd_color(0x1106), fg = lcd_color(0xffff);
    const uint16_t edge = lcd_color(0x4e7b), fill = lcd_color(0x1991);
    for (unsigned top = 0; top < SCREEN_H; top += ROW_H) {
        uint16_t pixels[ROW_H][SCREEN_W];
        for (unsigned row = 0; row < ROW_H; ++row)
            for (unsigned col = 0; col < SCREEN_W; ++col)
                pixels[row][col] = bg;
        for (unsigned item = 0; item < 9; ++item) {
            unsigned x = 2u + (item % 3u) * CELL_W;
            unsigned y = MENU_TOP + (item / 3u) * CELL_H;
            for (unsigned row = 0; row < CELL_H - 2u; ++row) {
                if (y + row < top || y + row >= top + ROW_H)
                    continue;
                for (unsigned col = 0; col < CELL_W - 2u; ++col) {
                    unsigned border = !row || row == CELL_H - 3u || !col || col == CELL_W - 3u;
                    if (item < count)
                        pixels[y + row - top][x + col] = item == menu_item ?
                            (border ? edge : fill) : (border ? fill : bg);
                    else if (item < 8 && border)
                        pixels[y + row - top][x + col] = fill;
                }
            }
            if (item >= count)
                continue;
            const char *label = names[item];
            unsigned n = 0;
            while (label[n])
                ++n;
            x += (CELL_W - n * 6u) / 2u;
            y += 13u;
            for (unsigned i = 0; i < n; ++i) {
                const uint8_t *glyph = wind_font[label[i] - 'A' + 11];
                for (unsigned row = 0; row < 7; ++row) {
                    if (y + row < top || y + row >= top + ROW_H)
                        continue;
                    for (unsigned col = 0; col < 5; ++col)
                        if (glyph[col] & (1u << row))
                            pixels[y + row - top][x + i * 6u + col] = fg;
                }
            }
        }
        stock_lcd_blit(0, SCREEN_W - 1, top, top + ROW_H - 1, pixels[0]);
    }
}

static WIND_NOINLINE void draw_line_spaced(unsigned y, const char *line, uint16_t foreground,
                                         uint16_t background, unsigned step)
{
    uint16_t pixels[ROW_H][SCREEN_W];
    foreground = lcd_color(foreground);
    background = lcd_color(background);
    for (unsigned row = 0; row < ROW_H; ++row)
        for (unsigned col = 0; col < SCREEN_W; ++col)
            pixels[row][col] = background;

    for (unsigned x = 6; *line && x + 10 <= SCREEN_W; ++line, x += step) {
        unsigned glyph = 0;
        if (*line >= '0' && *line <= '9')
            glyph = (unsigned)(*line - '0') + 1;
        if (*line >= 'A' && *line <= 'Z')
            glyph = (unsigned)(*line - 'A') + 11;
        if (*line == '%')
            glyph = 38;
        if (*line == '-')
            glyph = 39;
        for (unsigned col = 0; col < 5; ++col) {
            uint8_t bits = wind_font[glyph][col];
            for (unsigned row = 0; row < 7; ++row) {
                if (bits & (1u << row)) {
                    pixels[1 + row * 2][x + col * 2] = foreground;
                    pixels[1 + row * 2][x + col * 2 + 1] = foreground;
                    pixels[2 + row * 2][x + col * 2] = foreground;
                    pixels[2 + row * 2][x + col * 2 + 1] = foreground;
                }
            }
        }
    }
    stock_lcd_blit(0, SCREEN_W - 1, y, y + ROW_H - 1, pixels[0]);
}

static void draw_line(unsigned y, const char *line, uint16_t foreground, uint16_t background)
{
    draw_line_spaced(y, line, foreground, background, 12);
}

#ifdef WIND_PEDAL_ENABLED
static void pedal_label(uint16_t pixels[ROW_H][SCREEN_W], unsigned top, unsigned center,
                        unsigned y, const char *label, unsigned scale, uint16_t color)
{
    static const uint8_t arrows[2][5] = {
        {0x08, 0x1c, 0x2a, 0x08, 0x08},
        {0x08, 0x08, 0x2a, 0x1c, 0x08},
    };
    unsigned length = 0;
    while (label[length])
        ++length;
    unsigned x = center - (length * 6u - 1u) * scale / 2u;
    for (; *label; ++label, x += 6u * scale) {
        const uint8_t *glyph = wind_font[0];
        if (*label >= 'A' && *label <= 'Z')
            glyph = wind_font[*label - 'A' + 11];
        else if (*label == '<' || *label == '>')
            glyph = arrows[*label == '>'];
        for (unsigned row = 0; row < 7u * scale; ++row) {
            if (y + row < top || y + row >= top + ROW_H)
                continue;
            for (unsigned col = 0; col < 5u * scale; ++col)
                if (glyph[col / scale] & (1u << (row / scale)))
                    pixels[y + row - top][x + col] = color;
        }
    }
}

static WIND_NOINLINE void draw_pedal(void)
{
    const uint16_t bg = lcd_color(0x1106), fg = lcd_color(0xffff);
    const uint16_t card = lcd_color(0x1991), border = lcd_color(0x3355);
    const uint16_t accent = lcd_color(0x6e9f), muted = lcd_color(0xa5d3);
    drawn_pedal_ready = pedal_hid_ready() != 0;
    const char *status = drawn_pedal_ready ? "BLUETOOTH CONNECTED" : "WAITING FOR BLUETOOTH";
    const uint16_t status_color = drawn_pedal_ready ? lcd_color(0x5ecb) : muted;
    for (unsigned top = 0; top < SCREEN_H; top += ROW_H) {
        uint16_t pixels[ROW_H][SCREEN_W];
        for (unsigned row = 0; row < ROW_H; ++row) {
            unsigned y = top + row;
            for (unsigned x = 0; x < SCREEN_W; ++x) {
                uint16_t color = bg;
                if (y == 105u && x >= 8u && x < 152u)
                    color = border;
                if (y >= 47u && y <= 96u &&
                    ((x >= 8u && x <= 75u) || (x >= 84u && x <= 151u))) {
                    unsigned edge = y == 47u || y == 96u || x == 8u || x == 75u ||
                                    x == 84u || x == 151u;
                    color = edge ? border : card;
                }
                pixels[row][x] = color;
            }
        }
        pedal_label(pixels, top, 80, 9, "PEDAL", 3, fg);
        pedal_label(pixels, top, 80, 34, status, 1, status_color);
        pedal_label(pixels, top, 42, 53, "<", 4, accent);
        pedal_label(pixels, top, 118, 53, ">", 4, accent);
        pedal_label(pixels, top, 42, 83, "L PREV", 1, fg);
        pedal_label(pixels, top, 118, 83, "R NEXT", 1, fg);
        pedal_label(pixels, top, 80, 114, "VOL BACK", 1, muted);
        stock_lcd_blit(0, SCREEN_W - 1, top, top + ROW_H - 1, pixels[0]);
    }
}
#endif

static const char *number(char *buffer, const char *label, unsigned value, int valid)
{
    char *p = buffer;
    while (*label)
        *p++ = *label++;
    if (valid) {
        *p++ = '0' + value / 100u;
        *p++ = '0' + value / 10u % 10u;
        *p++ = '0' + value % 10u;
    } else {
        *p++ = '-';
        *p++ = '-';
        *p++ = '-';
    }
    *p = 0;
    return buffer;
}

static WIND_NOINLINE void draw_envelope_plot(unsigned part)
{
    const uint16_t bg = 0x1106, fg = 0xffff, accent = 0x4e7b;
    unsigned a = wind_get_env(WIND_ATTACK), d = wind_get_env(WIND_DECAY);
    unsigned s = wind_get_env(WIND_SUSTAIN), r = wind_get_env(WIND_RELEASE);
    unsigned total = a + d + r + 90u;
    unsigned x[] = {6, 18 + a * 68u / total, 30 + (a + d) * 68u / total,
                    102 - r * 68u / total, 154};
    unsigned y[] = {72, 8, 72 - s * 64u / 100u, 72 - s * 64u / 100u, 72};
    for (unsigned top = 0; top < 80; top += ROW_H) {
        uint16_t pixels[ROW_H][SCREEN_W];
        for (unsigned row = 0; row < ROW_H; ++row)
            for (unsigned col = 0; col < SCREEN_W; ++col)
                pixels[row][col] = lcd_color(bg);
        for (unsigned segment = 0; segment < WIND_ENV_PARTS; ++segment) {
            int previous_y = (int)y[segment];
            for (unsigned col = x[segment]; col <= x[segment + 1]; ++col) {
                int next_y = (int)y[segment] + ((int)y[segment + 1] - (int)y[segment]) *
                    (int)(col - x[segment]) / (int)(x[segment + 1] - x[segment]);
                int first = previous_y < next_y ? previous_y : next_y;
                int last = previous_y > next_y ? previous_y : next_y;
                for (int row = first; row <= last; ++row)
                    if ((unsigned)row >= top && (unsigned)row < top + ROW_H)
                        pixels[row - top][col] = lcd_color(segment == part ? accent : fg);
                previous_y = next_y;
            }
        }
        stock_lcd_blit(0, SCREEN_W - 1, top + 16, top + 16 + ROW_H - 1, pixels[0]);
    }
}

static void draw_envelope(void)
{
    static const char *const names[WIND_ENV_PARTS] = {"ATTACK ", "DECAY  ", "SUSTAIN", "RELEASE"};
    const uint16_t bg = 0x1106, fg = 0xffff, accent = 0x4e7b;
    unsigned part = selected - WIND_ENV_EDIT;
    draw_line(0, "ENV", accent, bg);
    draw_envelope_plot(part);
    char line[14];
    unsigned value = wind_get_env(part);
    number(line, names[part], value, 1);
    unsigned end = 10u;
    if (part == WIND_SUSTAIN) {
        line[end++] = ' ';
        line[end++] = '%';
    } else {
        line[end++] = '0';
        line[end++] = 'M';
        line[end++] = 'S';
    }
    line[end] = 0;
    draw_line(96, line, accent, bg);
    draw_line(112, "PUSH FOR BACK", fg, bg);
}

static void draw_controls(void)
{
    static const char *const waves[WIND_WAVE_COUNT] = {"WAVE SINE", "WAVE SAW", "WAVE SQUARE"};
    const uint16_t bg = 0x1106, fg = 0xffff, accent = 0x4e7b;
    unsigned cutoff = WIND_CUTOFF_MAX - cutoff_down;
    char line[] = "CUT 0000 HZ";
    unsigned hz = wind_cutoff_hz[cutoff];
    for (int i = 7; i >= 4; --i) {
        line[i] = '0' + hz % 10u;
        hz /= 10u;
    }
    char bend[] = "BEND 00 ST";
    bend[5] += wind_bend_ranges[bend_range] / 10u;
    bend[6] += wind_bend_ranges[bend_range] % 10u;
    char main_cc[12], alt_cc[12];
    const char *const rows[] = {
        waves[wave], cutoff == WIND_CUTOFF_MAX ? "CUT OFF" : line, bend,
        number(main_cc, "MAIN CC ", wind_get_breath_cc(0), 1),
        number(alt_cc, "ALT CC  ", wind_get_breath_cc(1), 1),
        wind_get_fx_route() ? "ROUTE FX" : "ROUTE DIRECT", "ENV", "BACK",
    };
    unsigned first = selected == WIND_BACK ? WIND_CUTOFF : WIND_WAVE;
    for (unsigned row = 0; row < 7; ++row) {
        unsigned item = first + row;
        draw_line((row + 1u) * ROW_H, rows[item - WIND_WAVE], selected == item ? accent : fg, bg);
    }
}

static void draw_panel(int full)
{
    const uint16_t bg = 0x1106, fg = 0xffff, accent = 0x4e7b;
#ifdef WIND_PEDAL_ENABLED
    if (menu_pedal) {
        if (full)
            draw_pedal();
        return;
    }
#endif
    if (menu_context && !menu_synth) {
        if (full)
            draw_menu();
        return;
    }
    if (selected) {
        if (full && selected >= WIND_ENV_EDIT)
            draw_envelope();
        else if (full) {
            draw_line(0, "SYNTH SETUP", accent, bg);
            draw_controls();
        }
        return;
    }
    wind_status_t now = wind_get_status();
    char line[14];
    if (full)
        draw_line(0, "WIND SYNTH", accent, bg);
    if (full || now.link != drawn.link || now.link_tracked != drawn.link_tracked)
        draw_line(16, now.link == 2 && now.link_tracked ? "BT READY" :
                  now.link_tracked ? "BT LINK" : now.link == 0 ? "BT WAIT" : "BT NO ID", fg, bg);
    if (full || now.notifications != drawn.notifications || now.messages != drawn.messages) {
        line[0] = 'R'; line[1] = 'X'; line[2] = ' ';
        uint32_t count = now.notifications;
        for (int i = 7; i >= 3; --i) {
            line[i] = '0' + count % 10u;
            count /= 10u;
        }
        line[8] = ' '; line[9] = 'M';
        line[10] = '0' + now.messages / 10u;
        line[11] = '0' + now.messages % 10u;
        line[12] = 0;
        draw_line(32, line, fg, bg);
    }
    if (full || now.note != drawn.note || now.channel != drawn.channel ||
        ((now.flags ^ drawn.flags) & (WIND_NOTE_SEEN | WIND_GATE))) {
        number(line, "NOTE ", now.note, now.flags & WIND_NOTE_SEEN);
        if (now.channel) {
            line[8] = ' ';
            line[9] = 'C';
            line[10] = '0' + now.channel / 10;
            line[11] = '0' + now.channel % 10;
            line[12] = 0;
        }
        draw_line(48, line, now.flags & WIND_GATE ? accent : fg, bg);
    }
    if (full || now.cc2 != drawn.cc2 || ((now.flags ^ drawn.flags) & WIND_CC2_SEEN))
        draw_line(64, number(line, "MAIN CC ", now.cc2, now.flags & WIND_CC2_SEEN), fg, bg);
    if (full || now.cc74 != drawn.cc74 || ((now.flags ^ drawn.flags) & WIND_CC74_SEEN))
        draw_line(80, number(line, "ALT CC  ", now.cc74, now.flags & WIND_CC74_SEEN), fg, bg);
    if (full || now.audio_seen != drawn.audio_seen || now.pcm_active != drawn.pcm_active ||
        now.fx_ack != drawn.fx_ack) {
        const char *audio = !now.audio_seen ? "AUDIO WAIT" : now.pcm_active ? "AUDIO ACTIVE" : "AUDIO IDLE";
        if (wind_get_fx_route() && now.audio_seen) {
            if (now.fx_ack)
                audio = now.pcm_active ? "FX OK ACTIVE" : "FX OK IDLE";
            else
                audio = now.pcm_active ? "FX BYPASS ON" : "FX BYPASS";
        }
        draw_line(96, audio, fg, bg);
    }
    if (full)
        draw_line_spaced(112, "R SET  VOL HOME", accent, bg, 10);
    drawn = now;
}

static void invalidate_screen(void)
{
    /* The display registration stores its default display here and the
     * active screen in that display at +16 (stock 0x33596 and 0x335f8). */
    void *const display = *STOCK_DISPLAY_PTR;
    if (display) {
        void *const screen = *(void *const *)((const uint8_t *)display + 16);
        if (screen)
            stock_invalidate(screen);
    }
}

void wind_stock_menu_enter(void *context)
{
#ifdef WIND_PEDAL_ENABLED
    pedal_leave();
    menu_pedal = 0;
#endif
    menu_context = context;
    menu_item = menu_synth = 0;
    selected = WIND_MONITOR;
    knob_action = KNOB_NONE;
    panel_open = input_captured = 1;
    release_pending = 0;
    redraw = 2;
}

void wind_stock_menu_destroy(void)
{
    if (!menu_context)
        return;
#ifdef WIND_PEDAL_ENABLED
    pedal_leave();
    menu_pedal = 0;
#endif
    menu_context = 0;
    menu_synth = panel_open = redraw = 0;
    knob_action = KNOB_NONE;
}

static void open_stock_page(unsigned page)
{
#ifdef WIND_PEDAL_ENABLED
    pedal_leave();
    menu_pedal = 0;
#endif
    menu_context = 0;
    menu_synth = panel_open = redraw = 0;
    release_pending = 0;
    stock_open_page(page, 0);
    invalidate_screen();
}

static int adjust_menu(unsigned buttons, unsigned encoder, unsigned action)
{
    static const uint8_t stock_page[] = {STOCK_EFFECTS, STOCK_SETTINGS, STOCK_DRUM, STOCK_SHUTDOWN};
#ifdef WIND_PEDAL_ENABLED
    const unsigned count = 6u;
#else
    const unsigned count = 5u;
#endif
    if (action == KNOB_CLOSE) {
        open_stock_page(STOCK_HOME);
        return 0;
    }
    if (action == KNOB_CONFIRM) {
#ifdef WIND_PEDAL_ENABLED
        if (menu_item == 5u) {
            menu_pedal = 1;
            pedal_enter(buttons);
            return 1;
        }
#endif
        if (menu_item == 4u) {
            menu_synth = 1;
            selected = WIND_MONITOR;
            return 1;
        }
        open_stock_page(stock_page[menu_item]);
        return 0;
    }
    if (!buttons && (previous_button == 1u || previous_button == 2u)) {
        menu_item = (menu_item + (previous_button == 2u ? 1u : count - 1u)) % count;
        return 1;
    }
    if (encoder == 3u && (previous_encoder == 1u || previous_encoder == 2u)) {
        menu_item = (menu_item + (previous_encoder == 1u ? 1u : count - 1u)) % count;
        return 1;
    }
    return 0;
}

static int adjust_controls(unsigned buttons, unsigned encoder, unsigned action)
{
    int changed = 0;
    if (action == KNOB_CONFIRM && selected == WIND_MONITOR) {
        open_stock_page(STOCK_HOME);
        return 0;
    }
    if (action == KNOB_CONFIRM && selected >= WIND_ENV) {
        selected = selected == WIND_BACK ? WIND_MONITOR :
            selected == WIND_ENV ? WIND_ENV_EDIT : WIND_ENV;
        return 1;
    }
    if (!buttons && (previous_button == 1u || previous_button == 2u)) {
        if (selected >= WIND_ENV_EDIT)
            selected = WIND_ENV_EDIT + ((selected - WIND_ENV_EDIT + (previous_button == 2u ? 1u : 3u)) & 3u);
        else if (previous_button == 2u)
            selected = selected == WIND_BACK ? WIND_WAVE : selected + 1u;
        else
            selected = selected <= WIND_WAVE ? WIND_BACK : selected - 1u;
        return 1;
    }
    if (encoder == 3u && (previous_encoder == 1u || previous_encoder == 2u) &&
        selected != WIND_MONITOR) {
        int direction = previous_encoder == 1u ? 1 : -1;
        if (selected == WIND_WAVE)
            wave = (wave + WIND_WAVE_COUNT + direction) % WIND_WAVE_COUNT;
        else if (selected == WIND_CUTOFF) {
            int next = cutoff_down - direction;
            if (next >= 0 && next <= WIND_CUTOFF_MAX)
                cutoff_down = (uint8_t)next;
        } else if (selected == WIND_BEND) {
            bend_range = (bend_range + WIND_BEND_RANGES + direction) % WIND_BEND_RANGES;
        } else if (selected == WIND_CC_MAIN || selected == WIND_CC_ALT) {
            unsigned secondary = selected == WIND_CC_ALT;
            int next = (int)wind_get_breath_cc(secondary) + direction;
            if (next < 0 || next > 119)
                return 0;
            wind_set_breath_cc(secondary, (unsigned)next);
            return 1;
        } else if (selected == WIND_ROUTE) {
            wind_set_fx_route(direction > 0);
            return 1;
        } else if (selected >= WIND_ENV_EDIT) {
            unsigned part = selected - WIND_ENV_EDIT;
            int next = (int)wind_get_env(part) + direction;
            if (next < 0 || next > (part == WIND_SUSTAIN ? 100 : 127))
                return 0;
            wind_set_env(part, (unsigned)next);
            return 1;
        } else {
            return 0;
        }
        wind_set_controls(wave, WIND_CUTOFF_MAX - cutoff_down, bend_range);
        changed = 1;
    }
    return changed;
}

uint32_t wind_ui_tick(void)
{
    const uint32_t now = stock_tick();
    const unsigned buttons = !stock_gpio_get(0, 1u << 31) | ((!stock_gpio_get(12, 1u << 6)) << 1);
    const unsigned encoder = !stock_gpio_get(0, 1u << 29) | ((!stock_gpio_get(0, 1u << 30)) << 1);
    const unsigned action = knob_action;
    if (action)
        knob_action = KNOB_NONE;
#ifdef WIND_PEDAL_ENABLED
    if (menu_pedal) {
        if (action == KNOB_CONFIRM) {
            pedal_leave();
            menu_pedal = 0;
            previous_button = 0;
            previous_encoder = encoder;
            chord = latched = buttons == 3u;
            redraw = 2;
        } else {
            pedal_tick(buttons);
            if (drawn_pedal_ready != (pedal_hid_ready() != 0))
                redraw = 2;
        }
        uint32_t result = stock_gui_timer();
        if (redraw) {
            draw_panel(1);
            redraw = 0;
        }
        return result;
    }
#endif
    const int pressed = buttons == 3u;
    if (panel_open && !chord && !pressed &&
        (menu_context && !menu_synth ? adjust_menu(buttons, encoder, action) :
         adjust_controls(buttons, encoder, action))) {
        redraw = 2;
        invalidate_screen();
    }
    previous_button = chord || pressed ? 0 : buttons;
    previous_encoder = encoder;
    if (!pressed) {
        chord = latched = 0;
    } else if (!chord) {
        chord = 1;
        chord_since = now;
    } else if (!latched && now - chord_since >= 600u) {
        latched = 1;
        if (menu_context)
            menu_synth = 0;
        else
            panel_open ^= 1u;
        selected = WIND_MONITOR;
        knob_action = KNOB_NONE;
        input_captured = 1;
        release_pending = 0;
        redraw = panel_open ? 2u : 0u;
        refresh_polls = 0;
        last_draw = now;
        invalidate_screen();
    }
    if (!panel_open && input_captured) {
        if (buttons) {
            release_pending = 0;
        } else if (!release_pending) {
            release_pending = 1;
            release_since = now;
        } else if (now - release_since >= 40u) {
            input_captured = 0;
        }
    }
    /* Request a real LVGL flush even when the stock screen has no input.
     * Each pass of the normal GUI loop already includes a one-tick delay. */
    if (panel_open && !redraw && (++refresh_polls >= 100u || now - last_draw >= 100u)) {
        redraw = 1;
        refresh_polls = 0;
        last_draw = now;
        invalidate_screen();
    }
    uint32_t result = stock_gui_timer();
    /* Preserve the direct draw path if LVGL has no active display to flush. */
    if (redraw) {
        draw_panel(redraw == 2u);
        redraw = 0;
    }
    return result;
}

/* Forward the ordinary stock CC path when the overlay releases input capture. */
void wind_stock_front_input(unsigned type, unsigned code, unsigned value, unsigned extra)
{
    if (!input_captured)
        stock_post_input(type, code, value, extra);
}

void wind_stock_key_input(unsigned type, unsigned code, unsigned value, unsigned extra)
{
    if (!input_captured) {
        stock_post_input(type, code, value, extra);
        return;
    }
    if (type != 2u || extra != 0u)
        return;
    /* Stock menu event 0x00030202 confirms the selection. The native key
     * scanner already debounces and classifies VOL before queueing it. */
    if (code == 2u && value == 3u)
        knob_action = KNOB_CONFIRM;
    else if ((code == 2u && value == 4u) || (code == 0x80u && value == 3u))
        knob_action = KNOB_CLOSE;
}

void wind_ui_blit(unsigned x1, unsigned x2, unsigned y1, unsigned y2, const uint16_t *pixels)
{
    if (!panel_open)
        stock_lcd_blit(x1, x2, y1, y2, pixels);
    else if (redraw) {
        draw_panel(redraw == 2u);
        redraw = 0;
    }
}
