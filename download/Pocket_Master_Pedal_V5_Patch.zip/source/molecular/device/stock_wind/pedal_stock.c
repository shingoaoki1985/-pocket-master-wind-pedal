/* SPDX-License-Identifier: GPL-3.0-only */
#include "pedal.h"
#include "pedal_profile.h"
#include <stddef.h>

typedef int16_t (*pedal_read)(uint16_t, uint16_t, uint16_t, uint8_t *, uint16_t);
typedef int16_t (*pedal_write)(uint16_t, uint16_t, uint16_t, uint16_t, uint8_t *, uint16_t);

/* Stock 1.3.3 constructs this profile on its BLE initialization stack. */
typedef struct {
    const uint8_t *database;
    pedal_read read;
    pedal_write write;
    uint8_t settings[36];
    const uint8_t *advertising;
    uint32_t advertising_size;
} stock_profile;

extern unsigned stock_ble_init(void *context, stock_profile *profile);
extern int16_t stock_ble_read(uint16_t, uint16_t, uint16_t, uint8_t *, uint16_t);
extern int16_t stock_ble_write(uint16_t, uint16_t, uint16_t, uint16_t, uint8_t *, uint16_t);
extern int stock_ble_notify(uint16_t connection, uint16_t attribute, uint8_t *value, uint16_t size);
extern void stock_ble_advertise(const uint8_t *data, unsigned size);

static volatile uint16_t subscribed, pending;
static volatile uint8_t active, attached, suspended;
static volatile uint32_t tx_status;
static uint8_t advertising, last_key, original_advertising_size;
static const uint8_t *original_advertising;

void pedal_hid_enable(int enabled)
{
    if (enabled)
        tx_status = 0;
    active = enabled != 0;
    if (!active)
        pending = 0;
}

int pedal_hid_ready(void)
{
    return attached && active && subscribed && !suspended;
}

uint32_t pedal_hid_tx_status(void)
{
    return tx_status;
}

int pedal_hid_notify(const uint8_t report[PEDAL_REPORT_SIZE])
{
    if (!pedal_hid_ready() || pending)
        return 0;
    pending = 0x100u | report[2];
    return 1;
}

static int16_t read_value(const uint8_t *value, unsigned length, unsigned offset,
                          uint8_t *buffer, unsigned size)
{
    if (!buffer)
        return (int16_t)length;
    if (offset >= length)
        return 0;
    if (size > length - offset)
        size = length - offset;
    for (unsigned i = 0; i < size; ++i)
        buffer[i] = value[offset + i];
    return (int16_t)size;
}

static int16_t hid_read(uint16_t connection, uint16_t handle, uint16_t offset,
                        uint8_t *buffer, uint16_t size)
{
    if (handle == PEDAL_MAP)
        return read_value(pedal_hid_report_map, pedal_hid_report_map_size, offset, buffer, size);
    if (handle == PEDAL_INPUT) {
        const uint8_t report[PEDAL_REPORT_SIZE] = {0, 0, last_key};
        return read_value(report, sizeof report, offset, buffer, size);
    }
    if (handle == PEDAL_CCC) {
        const uint8_t value[2] = {subscribed == connection + 1u, 0};
        return read_value(value, sizeof value, offset, buffer, size);
    }
    return stock_ble_read(connection, handle, offset, buffer, size);
}

static int16_t hid_write(uint16_t connection, uint16_t handle, uint16_t transaction,
                         uint16_t offset, uint8_t *value, uint16_t size)
{
    if (handle == PEDAL_CCC || handle == PEDAL_CONTROL) {
        if (transaction || offset || !value)
            return 0x0du; /* invalid attribute value length */
        if (handle == PEDAL_CCC) {
            if (size != 2 || value[0] > 1u || value[1])
                return 0x0du;
            if (value[0] || subscribed == connection + 1u) {
                pending = last_key = suspended = 0;
                subscribed = value[0] ? connection + 1u : 0;
            }
        } else {
            if (size != 1 || value[0] > 1u)
                return 0x0du;
            if (subscribed == connection + 1u) {
                suspended = value[0] == 0;
                if (suspended)
                    pending = 0;
            }
        }
        return 0;
    }
    return stock_ble_write(connection, handle, transaction, offset, value, size);
}

unsigned pedal_stock_init(void *context, stock_profile *profile)
{
    if (profile->database == (const uint8_t *)0x142810u &&
        profile->read == stock_ble_read && profile->write == stock_ble_write &&
        profile->advertising_size <= 31u) {
        original_advertising = profile->advertising;
        original_advertising_size = (uint8_t)profile->advertising_size;
        profile->database = pedal_profile_data;
        profile->read = hid_read;
        profile->write = hid_write;
        attached = 1;
    }
    return stock_ble_init(context, profile);
}

void pedal_stock_disconnect(unsigned connection)
{
    if (subscribed == connection + 1u) {
        subscribed = pending = last_key = suspended = 0;
    }
}

/* Run from the same stock task that processes the native BLE setup. */
void pedal_stock_poll(void)
{
    static const uint8_t hid_advertising[] = {
        2, 0x01, 0x06, 3, 0x03, 0x12, 0x18, 3, 0x19, 0xc1, 0x03,
        13, 0x09, 'P', 'o', 'c', 'k', 'e', 't', ' ', 'P', 'e', 'd', 'a', 'l',
    };
    if (!attached)
        return;
    if (advertising != active) {
        advertising = active;
        if (advertising)
            stock_ble_advertise(hid_advertising, sizeof hid_advertising);
        else
            stock_ble_advertise(original_advertising, original_advertising_size);
    }
    unsigned connection = subscribed;
    unsigned request = active ? pending : last_key ? 0x100u : 0u;
    if (!connection || suspended || !request)
        return;
    uint8_t report[PEDAL_REPORT_SIZE] = {0, 0, (uint8_t)request};
    int result = stock_ble_notify((uint16_t)(connection - 1u), PEDAL_INPUT, report, sizeof report);
    unsigned sent = tx_status & 0xffffu;
    if (result == 0) {
        last_key = report[2];
        if (active && sent < 999u)
            ++sent;
        pending = 0;
    }
    if (active)
        tx_status = ((uint32_t)(uint16_t)result << 16) | sent;
}
