/* SPDX-License-Identifier: GPL-3.0-only */
#ifndef STOCK_WIND_PEDAL_H
#define STOCK_WIND_PEDAL_H

#include <stdint.h>

enum { PEDAL_REPORT_SIZE = 8, PEDAL_REPORT_ID = 1 };
extern const uint8_t pedal_hid_report_map[];
extern const unsigned pedal_hid_report_map_size;

/* The adapter owns advertising, pairing and report subscription. Disabling
 * discards pending presses and releases any key already sent. */
void pedal_hid_enable(int enabled);
int pedal_hid_ready(void);
int pedal_hid_notify(const uint8_t report[PEDAL_REPORT_SIZE]);
/* Upper 16 bits are the last native error, lower 16 bits count accepted reports. */
uint32_t pedal_hid_tx_status(void);

void pedal_enter(unsigned buttons);
void pedal_leave(void);
int pedal_tick(unsigned buttons);
unsigned pedal_last_key(void);

#endif
