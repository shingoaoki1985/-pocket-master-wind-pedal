# Pocket Master 1.3.3 Wind Synth V7.5

The experimental `--pedal` build adds PEDAL to the stock grid. Enter the
mode to advertise the BLE keyboard as Pocket Pedal. L and R send Left
Arrow and Right Arrow. VOL returns to the grid, cancels queued presses, and
restores the original advertising data. Device pairing and simultaneous
use with BLE MIDI still need a hardware test.

The build extends the stock peripheral GATT profile after its seven
existing attributes and preserves the original read/write handlers.
The stock task services the outgoing report queue.

V7.5 adds synth audio to the two raw ADC samples as well as the derived mono input. Its FX handshake uses a new marker so it falls back to DIRECT if the ARM is still running the earlier patch. The processed output still requires a device test.

V7.4 waits for the ARM effects processor to echo the FX frame marker. The performance monitor shows FX OK ACTIVE while the synth is generating and the marker returns. FX BYPASS ON indicates that the processor did not echo the marker and synth audio is going to the direct output. The echo verifies receipt of the marker, not sound from the effect chain.

V7.3 corrects the EFFECTS and DRUM destinations and restores direct synth audio as the boot default.

V7.2 maps the grid labels to the stock pages directly and adds VOL HOME to the SYNTH monitor.

V7.1 uses the stock debounced VOL key event to confirm selections in the grid and to open or close ENV and BACK.

Hold VALUE/VOL on the stock home screen to open the 3 x 3 menu. Turn the knob or press L/R to select EFFECTS, SETTINGS, DRUM, SHUTDOWN or SYNTH. Briefly press VALUE/VOL to open the selected item. One cell is blank and three outlined positions are reserved until items are specified. To close the grid, hold and release the knob. Briefly press VOL on the SYNTH monitor to return to the stock home screen. Hold L+R to return to the grid if SYNTH was opened from there. The L+R shortcut directly opens SYNTH from other stock screens.

Pair from the stock SETTINGS > BT screen. The performance monitor shows the BLE link, RX and MIDI message counts, the last note and channel, the two breath values and PCM status. The synth accepts MIDI channel 1. Set MAIN CC and ALT CC in SYNTH SETUP (0–119). Defaults are CC2 and CC74. The first message on the primary CC takes precedence over the secondary CC. The default mapping retains the previous CC11 expression alias.

Set WAVE, CUT or BEND with L/R and the knob. Select ENV and press the knob for the ADSR graph. Select a stage with L/R and turn to edit. Attack, decay and release range from 0 to 1270 ms in 10 ms steps. Sustain is 0 to 100 percent. The graph previews the configured envelope and highlights the stage being edited. Breath still controls the playing level. Short-press the knob to return from ENV, and select BACK to return to the performance monitor. Settings are kept in RAM.

The ROUTE setting defaults to DIRECT, which mixes the synth into the existing stereo playback stream. Turn the knob to select FX for an on-device comparison. FX sends the synth in a separate SPI block for the ARM's mono effects input. The effects route is experimental and was silent on the V7.2 device report. Turn back to DIRECT to restore the playback path. The setting is kept in RAM.

Keep the stock 1.3.3 image at `work/stock_v1.3.3.bin`. Run `outputs/build-pocket-master-stock-wind-v7-5.cmd` with Python and the Andes NDS32 toolchain. It saves `outputs/Pocket_Master_Stock_Wind_V7_5_candidate.bin`. The grid, controls and SPI packet layout can be tested on a PC. Stock menu transitions, the ARM update and effect processing require a device test.
