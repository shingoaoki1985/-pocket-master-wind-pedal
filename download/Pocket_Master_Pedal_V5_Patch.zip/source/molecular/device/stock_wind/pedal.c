/* SPDX-License-Identifier: GPL-3.0-only */
#include "pedal.h"

/* GATT carries the report ID in the Report Reference descriptor. The
 * notification value contains modifiers, a reserved byte and six usages. */
const uint8_t pedal_hid_report_map[] = {
    0x05, 0x01, 0x09, 0x06, 0xa1, 0x01,
    0x85, PEDAL_REPORT_ID,
    0x05, 0x07, 0x19, 0xe0, 0x29, 0xe7, 0x15, 0x00, 0x25, 0x01,
    0x75, 0x01, 0x95, 0x08, 0x81, 0x02,
    0x75, 0x08, 0x95, 0x01, 0x81, 0x01,
    0x19, 0x00, 0x29, 0x65, 0x15, 0x00, 0x25, 0x65,
    0x75, 0x08, 0x95, 0x06, 0x81, 0x00, 0xc0,
};
const unsigned pedal_hid_report_map_size = sizeof pedal_hid_report_map;

static uint8_t active, gesture, key, release_due, ready, last_gesture_key;

void pedal_enter(unsigned buttons)
{
    active = 1;
    gesture = buttons ? 3u : 0u;
    key = release_due = ready = last_gesture_key = 0;
    pedal_hid_enable(1);
}

void pedal_leave(void)
{
    if (!active)
        return;
    active = 0;
    key = release_due = ready = 0;
    pedal_hid_enable(0);
}

unsigned pedal_last_key(void)
{
    return last_gesture_key;
}

int pedal_tick(unsigned buttons)
{
    if (!active)
        return 0;
    int connected = pedal_hid_ready() != 0;
    int changed = connected != ready;
    ready = (uint8_t)connected;
    if (!ready)
        key = release_due = 0;
    if (buttons) {
        gesture = gesture && gesture != buttons ? 3u : (uint8_t)buttons;
    } else {
        if (gesture == 1u || gesture == 2u) {
            last_gesture_key = gesture == 1u ? 0x50u : 0x4fu;
            if (ready && !key)
                key = last_gesture_key;
            changed = 1;
        }
        gesture = 0;
    }
    if (key || release_due) {
        const uint8_t report[PEDAL_REPORT_SIZE] = {0, 0, release_due ? 0 : key};
        if (pedal_hid_notify(report)) {
            if (!release_due)
                key = 0;
            release_due ^= 1u;
        }
    }
    return changed;
}
