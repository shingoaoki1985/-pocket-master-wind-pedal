/* SPDX-License-Identifier: GPL-3.0-only */
#include <stdint.h>
#include <stddef.h>

#define EWI_MIDI_ACCEPT_EXPRESSION
#include "../../core/ewi_midi.c"
#include "wind_ui.h"

static void wind_message(uint8_t status, uint8_t data1, uint8_t data2);
#define ewi_midi_message wind_message
#include "../../core/ble_midi.c"
#undef ewi_midi_message
#include "wind_tables.h"

#ifndef WIND_HOST_TEST
/* GCC can emit this call for aggregate initialization in a freestanding build. */
void *memset(void *buffer, int value, size_t size)
{
    volatile unsigned char *byte = buffer;
    while (size--)
        *byte++ = (unsigned char)value;
    return buffer;
}

void *memcpy(void *buffer, const void *source, size_t size)
{
    volatile unsigned char *out = buffer;
    const unsigned char *in = source;
    while (size--)
        *out++ = *in++;
    return buffer;
}
#endif

static ble_midi_rx_t decoder;
static uint16_t midi_link;
static volatile uint16_t active_link; /* Bluetooth connection handle plus one */
static volatile uint32_t voice;
static uint32_t phase;
static int32_t level;
static int32_t filtered;
static volatile int16_t pitch_bend;
static volatile uint32_t controls;
static volatile uint32_t env_settings;
static volatile uint8_t fx_route;
static uint32_t envelope, release_step;
static uint8_t env_phase;
static uint8_t primary_seen;
static uint16_t last_breath_config;
static volatile wind_status_t status;

const uint8_t wind_bend_ranges[WIND_BEND_RANGES] = {2, 12, 24};

#define WIND_CONTROL_MASK 0x3ffffu
#define WIND_CC_DEFAULT ((2u << 18) | (74u << 25))
#define WIND_ENV_DEFAULT (100u << 16)
#define WIND_GATE_BIT (UINT32_C(1) << 31)
#define WIND_ENV_PEAK (UINT32_C(1) << 24)

void wind_set_controls(unsigned wave, unsigned cutoff, unsigned bend_range)
{
    controls = (controls & ~WIND_CONTROL_MASK) | wave |
        ((WIND_CUTOFF_MAX - cutoff) << 8) | (bend_range << 16);
}

unsigned wind_get_breath_cc(unsigned secondary)
{
    return ((controls ^ WIND_CC_DEFAULT) >> (secondary ? 25u : 18u)) & 127u;
}

void wind_set_breath_cc(unsigned secondary, unsigned cc)
{
    unsigned shift = secondary ? 25u : 18u;
    uint32_t mask = UINT32_C(127) << shift;
    controls = (controls & ~mask) | (((uint32_t)cc << shift ^ WIND_CC_DEFAULT) & mask);
}

unsigned wind_get_env(unsigned part)
{
    return ((env_settings ^ WIND_ENV_DEFAULT) >> (8u * part)) & 255u;
}

void wind_set_env(unsigned part, unsigned value)
{
    unsigned shift = 8u * part;
    uint32_t mask = UINT32_C(255) << shift;
    env_settings = (env_settings & ~mask) | (((uint32_t)value << shift ^ WIND_ENV_DEFAULT) & mask);
}

static uint32_t bent_step(unsigned note, int bend, unsigned range)
{
    int pitch = (int)note * 8192 + bend * (int)range;
    if (pitch <= 0)
        return wind_step[0];
    if (pitch >= 127 * 8192)
        return wind_step[127];
    unsigned lower = (unsigned)pitch >> 13;
    uint32_t delta = wind_step[lower + 1] - wind_step[lower];
    return wind_step[lower] + (uint32_t)(((uint64_t)delta * ((unsigned)pitch & 8191u)) >> 13);
}

static void wind_message(uint8_t code, uint8_t id, uint8_t value)
{
    status.messages = (status.messages + 1u) % 100u;
    if ((code >> 4) == 8u || (code >> 4) == 9u) {
        status.note = id;
        status.channel = (code & 15u) + 1u;
        status.flags |= WIND_NOTE_SEEN;
    }
    if ((code >> 4) == 11u) {
        status.channel = (code & 15u) + 1u;
        unsigned config = (controls ^ WIND_CC_DEFAULT) >> 18;
        unsigned primary = config & 127u, secondary = config >> 7;
        if (config != last_breath_config) {
            last_breath_config = (uint16_t)config;
            primary_seen = 0;
            status.flags &= ~(WIND_CC2_SEEN | WIND_CC74_SEEN);
        }
        if (code == 0xb0u && id == primary) {
            primary_seen = 1;
            status.cc2 = value;
            status.flags |= WIND_CC2_SEEN;
            id = 2u;
        } else if (code == 0xb0u && id == secondary) {
            status.cc74 = value;
            id = primary_seen ? 127u : 2u;
            status.flags |= WIND_CC74_SEEN;
        } else if (id == 2u || (id == 11u && config != (2u | (74u << 7)))) {
            /* Keep the legacy CC11 alias when using the defaults. */
            id = 127u;
        }
    }
    ewi_midi_message(code, id, value);
    if (code == 0xe0u)
        pitch_bend = ewi_midi.bend;
    status.flags = (status.flags & ~WIND_GATE) | (ewi_midi.down ? WIND_GATE : 0u);
}

static uint32_t voice_value(void)
{
    const uint32_t target = (uint32_t)ewi_midi.breath * ewi_midi.velocity / 4;
    return (ewi_midi.down ? WIND_GATE_BIT : 0u) |
        ((uint32_t)(midi_link & 0xfffu) << 19) | (target << 7) | ewi_midi.note;
}

void wind_reset(void)
{
    ewi_midi_disconnect();
    voice = 0;
    pitch_bend = 0;
    status.flags = 0;
    status.notifications = 0;
    status.messages = 0;
    status.channel = 0;
    primary_seen = 0;
}

void wind_stock_link(unsigned state, unsigned handle)
{
    /* In stock 1.3.3, discovery completion writes (2, 0).
     * Keep the actual handle supplied on connection. */
    if (state == 2u)
        return;
    active_link = 0;
    wind_reset();
    if (state == 1u && handle < 0xf00u)
        active_link = (uint16_t)(handle + 1u);
}

void wind_stock_disconnect(unsigned handle)
{
#if defined(WIND_PEDAL_ENABLED) && !defined(WIND_HOST_TEST)
    extern void pedal_stock_disconnect(unsigned connection);
    pedal_stock_disconnect(handle);
#endif
    if (active_link && active_link == handle + 1u)
        wind_stock_link(0, 0);
}

/* Link and packet layout are supplied by the stock v1.3.3 adapter. */
void wind_midi(uint16_t link, const uint8_t *data, uint32_t size)
{
    if (size < 3 || (data[0] & 0xc0u) != 0x80u)
        return;
    if (!ewi_midi.connected || midi_link != link) {
        ewi_midi_connect(0, 0);
        midi_link = link;
    }
    ble_midi_receive(&decoder, data, size);
    voice = voice_value();
}

static int16_t mix_sample(int16_t base, int32_t sample)
{
    int32_t value = base + sample;
    if (value > INT16_MAX)
        value = INT16_MAX;
    if (value < INT16_MIN)
        value = INT16_MIN;
    return (int16_t)value;
}

/* A, D and R are in 10 ms units (441 samples per unit). */
static unsigned envelope_step(unsigned span, unsigned units)
{
    unsigned samples = 441u * units;
    return samples ? (span + samples - 1u) / samples : span;
}

static void wind_mix(int16_t *pcm, uint32_t frames, uint16_t link, int connected, unsigned channels)
{
    uint32_t current = voice;
    uint32_t settings = controls;
    unsigned wave = settings & 255u;
    unsigned cutoff = WIND_CUTOFF_MAX - ((settings >> 8) & 255u);
    uint32_t step = bent_step(current & 127u, pitch_bend, wind_bend_ranges[(settings >> 16) & 3u]);
    int32_t alpha = wind_filter[cutoff];
    int32_t target = 0;
    int gate = connected && (current & WIND_GATE_BIT) && ((current >> 19) & 0xfffu) == link;
    const uint32_t env = env_settings ^ WIND_ENV_DEFAULT;
    const unsigned sustain = ((env >> 16) & 255u) * WIND_ENV_PEAK / 100u;
    const unsigned attack = envelope_step(WIND_ENV_PEAK, env & 255u);
    const unsigned decay = envelope_step(WIND_ENV_PEAK - sustain, (env >> 8) & 255u);
    if (gate) {
        target = (current >> 7) & 0xfffu;
        if (env_phase == WIND_RELEASE) {
            env_phase = WIND_ATTACK;
            envelope = 0;
        }
    } else {
        if (env_phase != WIND_RELEASE)
            release_step = envelope_step(envelope, env >> 24);
        env_phase = WIND_RELEASE;
        if (!connected)
            envelope = 0;
    }

    for (uint32_t i = 0; i < frames && (gate || envelope || level || filtered); ++i) {
        if (env_phase == WIND_ATTACK) {
            unsigned next = envelope + attack;
            envelope = next >= WIND_ENV_PEAK ? WIND_ENV_PEAK : next;
            if (envelope == WIND_ENV_PEAK)
                env_phase = WIND_DECAY;
        } else if (env_phase == WIND_DECAY) {
            envelope = envelope > sustain + decay ? envelope - decay : sustain;
            if (envelope == sustain)
                env_phase = WIND_SUSTAIN;
        } else if (env_phase == WIND_SUSTAIN) {
            envelope = sustain;
        } else {
            envelope = envelope > release_step ? envelope - release_step : 0;
        }
        if (gate) {
            level += (target - level) / 16;
            if (!target && level < 16)
                level = 0;
        } else if (!envelope) {
            level = 0;
        }
        int32_t shape = wind_sine[phase >> 24];
        if (wave == 1u)
            shape = (int32_t)(phase >> 16) - 32768;
        else if (wave == 2u)
            shape = phase < 0x80000000u ? 32767 : -32768;
        int32_t amplitude = ((int32_t)(envelope >> 9) * level) >> 15;
        int32_t sample = shape * amplitude >> 15;
        if (cutoff != WIND_CUTOFF_MAX) {
            filtered += ((sample * 8 - filtered) * alpha) / 32768;
            if (!amplitude && filtered > -64 && filtered < 64)
                filtered = 0;
            sample = filtered / 8;
        } else {
            filtered = 0;
        }
        phase += step;
        for (unsigned channel = 0; channel < channels; ++channel) {
            unsigned index = channels * i + channel;
            pcm[index] = mix_sample(pcm[index], sample);
        }
    }
    status.pcm_active = (envelope != 0 && level != 0) || filtered != 0;
}

#ifdef WIND_HOST_TEST
static uint8_t stock_central[10];
#define STOCK_CENTRAL stock_central
#else
#define STOCK_CENTRAL ((volatile const uint8_t *)0x200084b0u)
#endif

static uint16_t read16(volatile const uint8_t *data)
{
    return (uint16_t)(data[0] | ((uint16_t)data[1] << 8));
}

void wind_stock_receive(const uint8_t *event, uint32_t size)
{
    if (size < 1 || event[0] != 0xa7)
        return;
    status.notifications = (status.notifications + 1u) % 100000u;
    if (size < 11 || size > 520)
        return;
    uint16_t link = read16(event + 2);
    if (active_link && active_link == link + 1u)
        wind_midi(link, event + 8, size - 8);
}

static void wind_render_audio(int16_t *pcm, unsigned channels)
{
    status.audio_seen = 1;
    uint16_t link = active_link;
    wind_mix(pcm, 64, (uint16_t)(link - 1u), link != 0, channels);
}

unsigned wind_get_fx_route(void)
{
    return fx_route;
}

void wind_set_fx_route(unsigned enabled)
{
    fx_route = enabled != 0;
}

void wind_stock_audio_transfer(int16_t *transfer, const uint8_t *received)
{
    /* The first 256 bytes are the stock stereo stream. The ARM sees the
     * extension one byte later, with the signature at its offset 260. */
    unsigned char *bytes = (unsigned char *)transfer;
    if (!fx_route) {
        status.fx_ack = 0;
        bytes[259] = 0;
        wind_render_audio(transfer, 2);
        return;
    }
    bytes[259] = 'S';
    bytes[260] = 'Y';
    bytes[261] = 'N';
    bytes[262] = '9';
    int16_t *mono = transfer + 132;
    for (unsigned i = 0; i < 64; ++i)
        mono[i] = 0;
    int accepted = 0;
    for (unsigned offset = 503; offset <= 505; ++offset) {
        if (received[offset] == 'S' && received[offset + 1] == 'Y' &&
            received[offset + 2] == 'N' && received[offset + 3] == '9') {
            accepted = 1;
            break;
        }
    }
    status.fx_ack = (uint8_t)accepted;
    if (accepted)
        wind_render_audio(mono, 1);
    else
        wind_render_audio(transfer, 2);
}

#ifdef WIND_HOST_TEST
static void wind_stock_audio(int16_t *stereo)
{
    wind_render_audio(stereo, 2);
}
#endif

wind_status_t wind_get_status(void)
{
    wind_status_t snapshot = status;
    snapshot.link = STOCK_CENTRAL[7];
    snapshot.link_tracked = active_link != 0;
    return snapshot;
}
