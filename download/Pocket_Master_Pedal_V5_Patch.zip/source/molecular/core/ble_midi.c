/* SPDX-License-Identifier: GPL-3.0-only
 * BLE-MIDI 1.0 receive adapter for the wind instrument. Call on the audio
 * render thread, after the transport has established the MIDI connection. */

typedef struct {
    uint32_t connection_id;
    uint8_t in_sysex;
} ble_midi_rx_t;

static void ble_midi_receive(ble_midi_rx_t *rx, const uint8_t *data, uint32_t size)
{
    uint8_t running = 0;
    uint8_t timestamp_required = 1;
    uint32_t i = 1;

    if (!ewi_midi.connected || size < 2u || (data[0] & 0xC0u) != 0x80u)
        return;
    if (rx->connection_id != ewi_midi.connection_id) {
        rx->connection_id = ewi_midi.connection_id;
        rx->in_sysex = 0;
    }

    while (i < size) {
        const uint8_t timestamp = data[i] & 0x80u;
        uint8_t status, length, first, second = 0;

        if (rx->in_sysex) {
            i++; /* raw SysEx byte, or timestamp before EOX/real-time */
            if (!timestamp || i == size)
                continue;
            if (data[i] == 0xF7u) {
                rx->in_sysex = 0;
                timestamp_required = 1;
            } else if (data[i] < 0xF8u) {
                rx->in_sysex = 0;
                return;
            }
            i++;
            continue;
        }
        if (timestamp) {
            if (++i == size)
                return;
        } else if (timestamp_required) {
            return;
        }

        status = running;
        if (data[i] & 0x80u) {
            status = data[i++];
            if (status < 0xF0u)
                running = status;
        } else if (!running) {
            return;
        }

        if (status == 0xF0u) {
            rx->in_sysex = 1;
            continue;
        }
        if (status >= 0xF0u) {
            timestamp_required = 1;
            length = status == 0xF2u ? 2u : (status == 0xF1u || status == 0xF3u);
        } else {
            timestamp_required = 0;
            length = (status & 0xE0u) == 0xC0u ? 1u : 2u;
        }
        if (size - i < length || (length && data[i] & 0x80u)
            || (length == 2u && data[i + 1u] & 0x80u))
            return;
        if (status < 0xF0u) {
            first = data[i];
            if (length == 2u)
                second = data[i + 1u];
            ewi_midi_message(status, first, second);
        }
        i += length;
    }
}
