/* SPDX-License-Identifier: GPL-3.0-only
 * MIDI input for a wind controller, with a USB-MIDI 1.0 adapter.
 * Call the input functions on the thread that renders the audio blocks. */

typedef struct {
    uint8_t configuration;
    uint8_t interface_number;
    uint8_t endpoint;
    uint8_t max_packet;
} ewi_usb_pipe_t;

typedef struct {
    uint32_t note_id;
    uint32_t connection_id;
    int16_t bend;
    uint8_t channel, cable, breath, note, velocity;
    uint8_t connected, down;
} ewi_midi_t;

static ewi_midi_t ewi_midi;

/* Select an alternate-setting-zero MIDI 1.0 streaming interface with a
 * full-speed bulk IN endpoint. The host driver owns the USB transactions. */
static int ewi_usb_find_pipe(const uint8_t *data, uint32_t size, ewi_usb_pipe_t *pipe)
{
    uint32_t offset, total;
    uint8_t interface_number = 0;
    int streaming = 0, midi1 = 0;
    if (size < 9u || data[0] != 9u || data[1] != 2u || data[5] == 0u)
        return 0;
    total = data[2] | ((uint32_t)data[3] << 8);
    if (total < 9u || total > size)
        return 0;
    for (offset = 9u; offset < total;) {
        const uint8_t *d = data + offset;
        uint32_t n = d[0];
        if (n < 2u || n > total - offset)
            return 0;
        if (d[1] == 4u) {
            if (n < 9u)
                return 0;
            interface_number = d[2];
            streaming = d[3] == 0u && d[5] == 1u && d[6] == 3u && d[7] == 0u;
            midi1 = 0;
        } else if (streaming && d[1] == 0x24u && n >= 7u && d[2] == 1u) {
            midi1 = d[3] == 0u && d[4] == 1u;
        } else if (midi1 && d[1] == 5u && n >= 7u && (d[2] & 0xF0u) == 0x80u
                   && (d[2] & 0x0Fu) != 0u && (d[3] & 3u) == 2u && d[5] == 0u) {
            uint8_t max_packet = d[4];
            if (max_packet == 8u || max_packet == 16u || max_packet == 32u || max_packet == 64u) {
                *pipe = (ewi_usb_pipe_t){data[5], interface_number, d[2], max_packet};
                return 1;
            }
        }
        offset += n;
    }
    return 0;
}

/* Channel and virtual cable are zero-based. Before the first breath message,
 * allow instruments that send only notes to play at full breath. */
static void ewi_midi_connect(uint8_t channel, uint8_t cable)
{
    uint32_t connection_id = ewi_midi.connection_id + 1u;
    ewi_midi = (ewi_midi_t){0};
    ewi_midi.connection_id = connection_id;
    ewi_midi.channel = channel;
    ewi_midi.cable = cable;
    ewi_midi.breath = 127;
    ewi_midi.connected = 1;
}

static void ewi_midi_disconnect(void)
{
    ewi_midi.down = 0;
    ewi_midi.connected = 0;
}

static void ewi_midi_message(uint8_t status, uint8_t data1, uint8_t data2)
{
    if (!ewi_midi.connected || (status & 15u) != ewi_midi.channel
        || (data1 | data2) >= 128u)
        return;

    switch (status >> 4) {
    case 9:
        if (data2) {
            ewi_midi.note = data1;
            ewi_midi.velocity = data2;
            ewi_midi.down = 1;
            ewi_midi.note_id++;
            break;
        }
        /* A zero-velocity Note On is a Note Off. */
        /* fall through */
    case 8:
        if (data1 == ewi_midi.note)
            ewi_midi.down = 0;
        break;
    case 11:
        if (data1 == 2u
#ifdef EWI_MIDI_ACCEPT_EXPRESSION
            || data1 == 11u
#endif
        )
            ewi_midi.breath = data2;
        break;
    case 14:
        ewi_midi.bend = (int16_t)(((int32_t)data2 << 7) + data1 - 8192);
        break;
    }
}

static void ewi_midi_receive(const uint8_t *data, uint32_t size)
{
    uint32_t i;
    if (!ewi_midi.connected || size % 4u)
        return;
    for (i = 0; i < size; i += 4u) {
        const uint8_t *p = data + i;
        uint8_t cin = p[0] & 15u;
        if ((p[0] >> 4) != ewi_midi.cable || (p[1] >> 4) != cin)
            continue;
        ewi_midi_message(p[1], p[2], p[3]);
    }
}
